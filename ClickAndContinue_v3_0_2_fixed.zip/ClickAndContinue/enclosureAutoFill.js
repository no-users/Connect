/**
 * enclosureAutoFill.js
 * ------------------------------------------------------------
 * Adds a visible "📎 Digital Saathi se Bharein" button on the
 * government portal's "Attach Enclosure(s)" step. The customer
 * clicks it on purpose (nothing runs automatically/silently) and
 * it fills every enclosure row it recognises:
 *   1. Selects the matching option in that row's "Enclosure
 *      Document" dropdown.
 *   2. Waits for the site's own script to un-disable that row's
 *      file input (the real portal disables it until a valid
 *      document type is chosen — this script waits for that
 *      instead of fighting it).
 *   3. Attaches the saved copy of that document (saved earlier
 *      from the popup's Documents tab) into the file input.
 *
 * 100% additive — does NOT modify or depend on content.js. Runs
 * as its own separate content script (see manifest.json), and
 * never touches "I Agree", the Word-verification/CAPTCHA box, or
 * the Proceed/Save/Cancel buttons. Every row can still be edited
 * by hand afterwards — nothing is ever locked.
 * ------------------------------------------------------------
 */

(function () {

  // Keyword lists to recognise each dropdown option's document type.
  // Matches the exact docType keys enclosureDocsPanel.js's dropdown
  // groups use, so a document saved there lines up here.
  //
  // IMPORTANT: several evidence-document options (खतियान, दानपत्र,
  // भूमि संबंधी दस्तावेज, भूमिहीनों वाला अभिलेख, अन्य राजस्व अभिलेख)
  // appear with IDENTICAL text under BOTH the Caste and Residence
  // certificate sections of the real form — but are saved under
  // different keys (caste_* vs revenue_*) in the Documents tab, since
  // a customer might only have evidence for one of the two. `altTypes`
  // lists the other key(s) to also try for that same option, so
  // whichever one was actually uploaded gets used — this is exactly
  // the bug that was reported ("भूमि संबंधी दस्तावेज" showing as "not
  // uploaded" even though it clearly was, just under the sibling key).
  const DOC_TYPE_KEYWORDS = [
    { type: "election_id", terms: ["निर्वाचन पहचान", "election id"] },
    { type: "voter_id", terms: ["मतदाता पहचान", "voter id"] },
    { type: "pension_doc", terms: ["पेंशन दस्तावेज", "pension document"] },
    { type: "driving_license", terms: ["ड्राइविंग लाइसेंस", "driving licence", "driving license"] },
    { type: "aadhaar", terms: ["आधार", "aadhaar", "aadhar"] },
    { type: "passbook", terms: ["पासबुक", "passbook"] },
    { type: "passport", terms: ["पासपोर्ट", "passport"] },
    // Order matters: health_insurance_card's own label text contains
    // smart_card_labour's shorter term as a substring, so the more
    // specific one MUST be checked first or every health-insurance
    // option would be misread as a plain labour smart card.
    { type: "health_insurance_card", terms: ["स्वास्थ्य बीमा", "health insurance"] },
    { type: "smart_card_labour", terms: ["स्मार्ट कार्ड (श्रम", "smart card"] },
    { type: "pan_card", terms: ["पैन कार्ड", "pan card"] },
    { type: "govt_id", terms: ["सरकारी पहचान पत्र", "government id"] },
    { type: "service_id", terms: ["सर्विस पहचान पत्र", "service id"] },

    { type: "revenue_khatiyan", altTypes: ["caste_khatiyan"], terms: ["खतियान"] },
    { type: "revenue_danpatra", altTypes: ["caste_danpatra"], terms: ["दानपत्र"] },
    { type: "revenue_land_doc", altTypes: ["caste_land_doc"], terms: ["भूमि संबंधी"] },
    { type: "revenue_landless_allotment", altTypes: ["caste_landless_allotment"], terms: ["भूमिहीनों"] },
    { type: "revenue_other", altTypes: ["caste_other_revenue"], terms: ["अन्य राजस्व अभिलेख"] },

    { type: "caste_site_inspection_request", terms: ["स्थल निरीक्षण"] },
    { type: "ration_card", terms: ["राशन कार्ड", "ration card"] },
    { type: "electricity_bill", terms: ["विद्युत विपत्र", "electricity bill"] },
    { type: "telephone_bill", terms: ["दूरभाष विपत्र", "telephone bill"] },

    { type: "salary_pension_slip", terms: ["वेतन / पेंशन पर्ची", "वेतन पेंशन पर्ची", "salary slip", "pension slip"] },
    { type: "income_tax_return", terms: ["आयकर रिटर्न", "income tax return"] },
    { type: "income_other", terms: ["अन्यान्य अभिलेख", "अन्यन्च अभिलेख", "अन्य अभिलेख"] },
  ];

  const DOC_TYPE_LABEL_HI = {
    election_id: "निर्वाचन पहचान पत्र",
    voter_id: "मतदाता पहचान पत्र",
    pension_doc: "पेंशन दस्तावेज",
    driving_license: "ड्राइविंग लाइसेंस",
    aadhaar: "आधार कार्ड",
    passbook: "पासबुक",
    passport: "पासपोर्ट",
    smart_card_labour: "स्मार्ट कार्ड",
    health_insurance_card: "स्वास्थ्य बीमा स्मार्ट कार्ड",
    pan_card: "पैन कार्ड",
    govt_id: "सरकारी पहचान पत्र",
    service_id: "सर्विस पहचान पत्र",
    revenue_khatiyan: "राजस्व अभिलेख - खतियान",
    caste_khatiyan: "राजस्व अभिलेख - खतियान",
    revenue_danpatra: "राजस्व अभिलेख - दानपत्र",
    caste_danpatra: "राजस्व अभिलेख - दानपत्र",
    revenue_land_doc: "राजस्व अभिलेख - भूमि संबंधी दस्तावेज",
    caste_land_doc: "राजस्व अभिलेख - भूमि संबंधी दस्तावेज",
    revenue_landless_allotment: "राजस्व अभिलेख - भूमिहीनों को आवंटित जमीन से संबंधित अभिलेख",
    caste_landless_allotment: "राजस्व अभिलेख - भूमिहीनों को आवंटित जमीन से संबंधित अभिलेख",
    revenue_other: "अन्य राजस्व अभिलेख",
    caste_other_revenue: "अन्य राजस्व अभिलेख",
    caste_site_inspection_request: "राजस्व अभिलेखों की अनुपलब्धता की स्थिति में स्थल निरीक्षण हेतु आग्रह",
    ration_card: "राशन कार्ड",
    electricity_bill: "विद्युत विपत्र",
    telephone_bill: "दूरभाष विपत्र",
    salary_pension_slip: "वेतन / पेंशन पर्ची",
    income_tax_return: "आयकर रिटर्न",
    income_other: "अन्यान्य अभिलेख",
  };

  function normalize(text) {
    return (text || "").toLowerCase();
  }

  // The real portal always names the dropdown "..._enclDoc_cb" and
  // the matching file input "..._attach" (same numeric field-id
  // prefix on both) — e.g. "7071_enclDoc_cb" + "7071_attach".
  function findEnclosureSelects() {
    return Array.from(document.querySelectorAll('select[id$="_enclDoc_cb"]'));
  }

  function fileInputFor(selectEl) {
    const fieldId = selectEl.id.replace(/_enclDoc_cb$/, "");
    return document.getElementById(fieldId + "_attach");
  }

  // Reads this row's own real size limit straight from the page (a
  // hidden field the portal already puts next to the file input) —
  // more reliable than hard-coding a number, since it can differ per
  // row/service. Falls back to 1MB if the field isn't found for some
  // reason.
  function maxBytesFor(fileInput) {
    const hidden = document.getElementById(fileInput.id + "_enclMaxSizeInBytes");
    const n = hidden ? parseInt(hidden.value, 10) : NaN;
    return Number.isFinite(n) && n > 0 ? n : 1024 * 1024;
  }

  // Returns EVERY document type this dropdown's options could match —
  // not just the first one in our keyword list. fillOneRow then tries
  // each candidate in turn and uses whichever one we actually have a
  // saved file for, instead of blindly locking onto whatever matched
  // first (that was the earlier bug: it could "find" a type like
  // Election ID before Aadhaar purely because of list order, even with
  // no saved Election ID file, and give up instead of trying Aadhaar).
  function matchCandidates(selectEl) {
    const options = Array.from(selectEl.options || []);
    const candidates = [];
    for (const opt of options) {
      const label = normalize(opt.textContent);
      for (const entry of DOC_TYPE_KEYWORDS) {
        if (entry.terms.some((t) => label.includes(normalize(t)))) {
          candidates.push({ docType: entry.type, option: opt });
          // Also try any sibling key(s) the SAME real-world document
          // could have been saved under (see the big comment above
          // DOC_TYPE_KEYWORDS) — this is the actual fix for "भूमि
          // संबंधी दस्तावेज shows as not uploaded even though it was":
          // this field existed before but was never read here.
          if (entry.altTypes) {
            entry.altTypes.forEach((alt) => candidates.push({ docType: alt, option: opt }));
          }
          break; // one recognised type per option is enough
        }
      }
    }
    return candidates;
  }

  function waitForEnabled(inputEl, timeoutMs) {
    return new Promise((resolve) => {
      if (!inputEl.disabled) return resolve(true);
      const start = Date.now();
      const timer = setInterval(() => {
        if (!inputEl.disabled) {
          clearInterval(timer);
          resolve(true);
        } else if (Date.now() - start > timeoutMs) {
          clearInterval(timer);
          resolve(false);
        }
      }, 150);
    });
  }

  async function buildFileFromDoc(docType) {
    if (typeof DocStore === "undefined") return null;
    try {
      return await DocStore.getDocAsFile(docType);
    } catch (err) {
      console.warn("ⓘ Not Read This File", docType, err);
      return null;
    }
  }

  function attachFileToInput(fileInput, file) {
    try {
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event("change", { bubbles: true }));
      fileInput.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    } catch (err) {
      console.warn("ⓘ Error Update Manual", err);
      return false;
    }
  }

  function showRowNote(anchorEl, message, kind) {
    const existing = anchorEl.parentElement.querySelector(
      ".saathi-enclosure-note[data-for='" + anchorEl.id + "']"
    );
    if (existing) existing.remove();
    const note = document.createElement("div");
    note.className = "saathi-enclosure-note";
    note.setAttribute("data-for", anchorEl.id);
    note.textContent = " " + message;
    note.style.cssText = [
      "margin-top:6px", "font-size:12px", "font-weight:600",
      "padding:5px 10px", "border-radius:8px", "display:inline-block",
      kind === "warn"
        ? "background:#FFF4E5;color:#9A6400;border:1px solid #F0DBA9;"
        : kind === "skip"
        ? "background:#F1F3F7;color:#5b6b85;border:1px solid #DDE3EC;"
        : "background:#E7F7F0;color:#1C6B46;border:1px solid #9ADFC2;",
    ].join(";");
    anchorEl.insertAdjacentElement("afterend", note);
  }

  async function fillOneRow(selectEl) {
    const fileInput = fileInputFor(selectEl);
    if (!fileInput) return;

    const candidates = matchCandidates(selectEl);
    if (candidates.length === 0) {
      showRowNote(fileInput, " ⓘ Document Match Error", "");
      return;
    }

    // Try each recognised option in turn, use the first one we actually
    // have a saved document for.
    for (const cand of candidates) {
      const file = await buildFileFromDoc(cand.docType);
      if (!file) continue;

      // This row may allow a smaller size than our own default cap
      // (or the saved file may predate a cap change) — check against
      // the real limit this exact row enforces before even trying,
      // so we never attach a file the site is just going to reject.
      const limit = maxBytesFor(fileInput);
      if (file.size > limit) {
        const limitMb = (limit / (1024 * 1024)).toFixed(limit % (1024 * 1024) === 0 ? 0 : 1);
        showRowNote(
          fileInput,
          `ⓘ Pdf Max ${limitMb} MB`,
          ""
        );
        continue;
      }

      // 1) Select the right document type — this triggers the portal's
      //    own enclosureDoc() handler, which un-disables the file input.
      selectEl.value = cand.option.value;
      selectEl.dispatchEvent(new Event("change", { bubbles: true }));

      // 2) The file input starts out disabled="disabled" on this portal.
      //    Wait for the site's own script to enable it before touching it.
      const enabled = await waitForEnabled(fileInput, 4000);
      if (!enabled) {
        showRowNote(fileInput, `ⓘ Document Chose Box Not Open`, "");
        return;
      }

      // 3) Attach the saved file.
      const attached = attachFileToInput(fileInput, file);
      if (attached) {
        showRowNote(fileInput, `☣︎ Document Updated`, "");
      } else {
        showRowNote(fileInput, `ⓘ Document Not Updated`, "");
      }
      return;
    }

    // None of this row's recognised options have a saved document yet.
    showRowNote(
      fileInput,
      `ⓘ Document Not Available`,
      ""
    );
  }

  async function fillAllRows(button) {
    const selects = findEnclosureSelects();
    if (selects.length === 0) {
      button.textContent = "ⓘ Row Not Found";
      setTimeout(() => resetButton(button), 2200);
      return;
    }
    button.disabled = true;
    button.textContent = "⏳ Loading...";
    for (const sel of selects) {
      await fillOneRow(sel);
    }
    button.disabled = false;
    button.textContent = "🌸 Update Again";
    setTimeout(() => resetButton(button), 2500);
  }

  function resetButton(button) {
    button.textContent = "🕊️ Update Page";
  }

  // Same shared pill look as activeProfileBadge.js's "Active: <name>"
  // badge — duplicated here (not imported) since content scripts can't
  // share modules, but guarded by id so only one copy of the stylesheet
  // ever lands on the page regardless of which script runs first.
  function injectBadgeStyles() {
    if (document.getElementById("saathiOnPageBadgeStyles")) return;
    const style = document.createElement("style");
    style.id = "saathiOnPageBadgeStyles";
    style.textContent = `
      @keyframes saathiBadgeIn {
        from { opacity: 0; transform: translateY(6px) scale(0.95); }
        to   { opacity: 1; transform: translateY(0) scale(1); }
      }
      @keyframes saathiDotPulse {
        0%   { box-shadow: 0 0 0 0 rgba(76, 217, 123, 0.55); }
        70%  { box-shadow: 0 0 0 7px rgba(76, 217, 123, 0); }
        100% { box-shadow: 0 0 0 0 rgba(76, 217, 123, 0); }
      }
      @keyframes saathiValueShimmer { to { background-position: -200% center; } }
      .saathi-onpage-badge {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        font-family: Arial, sans-serif;
        background: linear-gradient(135deg, #24365c 0%, #14203a 100%);
        color: #fff;
        border: 1px solid rgba(217, 164, 78, 0.55);
        border-radius: 999px;
        box-shadow: 0 8px 20px -6px rgba(0,0,0,0.45), inset 0 1px 0 rgba(255,255,255,0.08);
        animation: saathiBadgeIn 0.35s cubic-bezier(0.16,1,0.3,1);
      }
      .saathi-onpage-badge .saathi-dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: #4cd97b;
        flex-shrink: 0;
        animation: saathiDotPulse 1.8s ease-out infinite;
      }
      .saathi-onpage-badge .saathi-value {
        font-weight: 700;
        background: linear-gradient(90deg, #eabd6a 0%, #fff5da 50%, #eabd6a 100%);
        background-size: 200% auto;
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        animation: saathiValueShimmer 2.5s linear infinite;
      }
    `;
    document.documentElement.appendChild(style);
  }

  injectBadgeStyles();

  let injectInProgress = false;

  async function injectButton() {
    if (document.getElementById("saathiEnclosureFillBtn")) return;
    // Reserve the slot SYNCHRONOUSLY, before the "await" below — the
    // page fires many rapid DOM mutations while loading, and the
    // MutationObserver can re-run this function again during that
    // await (before the button actually exists yet to be caught by
    // the check above), which was inserting a second copy. This flag
    // closes that window: only one call can be "in flight" at a time.
    if (injectInProgress) return;
    injectInProgress = true;

    try {
      const selects = findEnclosureSelects();
      if (selects.length === 0) return;

      // Anchor the button just above the first enclosure row so it's
      // clearly next to what it fills, without disturbing the portal's
      // own layout (I Agree / CAPTCHA / Proceed stay completely untouched).
      const anchor = selects[0].closest(".box") || selects[0].closest("form") || document.body;

      const wrap = document.createElement("div");
      wrap.style.cssText = "margin:10px 0;";

      const profileLabel = typeof DocStore !== "undefined" ? await DocStore.getActiveProfileLabel() : null;

      // Re-check right after the await, in case something else (e.g. a
      // page reflow) already inserted it while we were waiting.
      if (document.getElementById("saathiEnclosureFillBtn")) return;

      const note = document.createElement("div");
      note.style.cssText = "font-size:12px;font-weight:700;margin-bottom:6px;padding:6px 10px;border-radius:8px;" +
        (profileLabel ? "background:#EAF9F1;color:#1c6b46;" : "background:#FFF4E5;color:#9A6400;");
      note.textContent = profileLabel
        ? "🌸" + profileLabel
        : "🌸 Profile Not Available";
      wrap.appendChild(note);

      const btn = document.createElement("button");
      btn.type = "button";
      btn.id = "saathiEnclosureFillBtn";
      btn.textContent = "🕊️ Update Page";
      btn.style.cssText = [
        "display:block", "padding:10px 18px",
        "font-size:13.5px", "font-weight:700", "color:#fff",
        "background:linear-gradient(135deg,#2f6fb8,#1c2b4a)",
        "border:none", "border-radius:10px", "cursor:pointer",
        "box-shadow:0 6px 16px -6px rgba(47,111,184,.5)",
      ].join(";");
      btn.addEventListener("click", () => fillAllRows(btn));
      wrap.appendChild(btn);

      anchor.parentElement
        ? anchor.parentElement.insertBefore(wrap, anchor)
        : document.body.insertBefore(wrap, document.body.firstChild);
    } finally {
      injectInProgress = false;
    }
  }

  const observer = new MutationObserver(() => injectButton());
  observer.observe(document.body, { childList: true, subtree: true });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", injectButton);
  } else {
    injectButton();
  }
})();
